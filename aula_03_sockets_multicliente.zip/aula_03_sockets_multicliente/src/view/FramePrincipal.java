package view;

import Classes.ClasseCliente;
import Classes.ClasseMen;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

public class FramePrincipal extends javax.swing.JFrame {

    private ButtonGroup group;
    private ClasseCliente usuario;
    private DefaultListModel<ClasseCliente> listaClientes;
    private DefaultListModel<ClasseMen> listaMensagens;
    private SwingWorker esperaClientes;
    private SwingWorker esperaMensagensNovas;

    private boolean flag;
    private Semaphore semaphore;
    private boolean on = false;

    public FramePrincipal() throws InterruptedException {
        
        initComponents();
        config();

        SairBTN.setEnabled(false);
    }
    
    private void config() throws InterruptedException {
        this.semaphore = new Semaphore(1);
        this.flag = false;
        this.setLocationRelativeTo(null);
        this.listaClientes = new DefaultListModel<>();
        this.listaMensagens = new DefaultListModel<>();
        this.ListaCliente.setModel(this.listaClientes);
        this.jListMsg.setModel(this.listaMensagens);

//        this.group = new ButtonGroup();
//        this.group.add(LigarBTN);
//        this.group.add(SairBTN);

        this.esperaClientes = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                while (true) {
                    System.out.println("");//Sem isso o código misteriosamente quebra
                    if (on) {
                        ClasseMen msg = new ClasseMen("LISTAR;CLIENTES", "");
                        try {
                            semaphore.acquire();
                            if (on) {
                                usuario.EviMen(msg);
                                atualizarClientes(usuario);
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Erro ao receber os clientes", "Erro", JOptionPane.ERROR_MESSAGE);
                        } finally {
                            semaphore.release();
                            Thread.sleep(500);
                        }
                    }
                }
            }
        };
        this.esperaClientes.execute();
        this.esperaMensagensNovas = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                ClasseMen msg;
                while (true) {
                    System.out.println("");//Sem isso o código misteriosamente quebra
                    if (on) {
                        if (BTNCvsGeral.isSelected()) {
                            msg = new ClasseMen("LISTAR;MENSAGENS;GERAL;", "");

                            ArrayList<ClasseMen> list;
                            try {
                                semaphore.acquire();
                                if (on) {
                                    usuario.EviMen(msg);
                                    list = (ArrayList<ClasseMen>) usuario.ReceberMen();
                                    listaMensagens.clear();
                                    listaMensagens.addAll(list);
                                }
                            } catch (Exception ex) {
                                System.out.println(ex.getMessage());
                                ex.printStackTrace();
                            } finally {
                                semaphore.release();
                                Thread.sleep(500);
                            }
                        } else if (ListaCliente.getSelectedIndex() != -1) {
                            try {
                                msg = new ClasseMen("LISTAR;MENSAGENS;DIRETA;", "");
                                msg.setDestinatarioID(ListaCliente.getSelectedValue().getId());

                                semaphore.acquire();
                                if (on) {
                                    usuario.EviMen(msg);
                                    ArrayList<ClasseMen> list = (ArrayList<ClasseMen>) usuario.ReceberMen();
                                    listaMensagens.clear();
                                    listaMensagens.addAll(list);
                                }
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            } finally {
                                semaphore.release();
                                Thread.sleep(500);
                            }
                        }

                    }
                }
            }
        };
        this.esperaMensagensNovas.execute();
    }
    
    private void atualizarClientes(ClasseCliente usuario) throws Exception {
        ArrayList<ClasseCliente> clientes = (ArrayList<ClasseCliente>) this.usuario.ReceberMen();
        DefaultListModel<ClasseCliente> temp = new DefaultListModel<>();
        temp.addAll(clientes);

        if (this.listaClientes != temp) {
            ClasseCliente client = this.ListaCliente.getSelectedValue();
            this.listaClientes.clear();
            this.listaClientes.addAll(clientes);

            int indice = -1;
            if (client != null) {
                long clienteSelecionado = client.getId();
                for (ClasseCliente it : clientes) {
                    if (it.getId() == clienteSelecionado) {
                        indice = listaClientes.indexOf(it);
                    }
                }
            }

            this.ListaCliente.setSelectedIndex(indice);
        }

    }

    private void esperaMsg() {
        try {
            ArrayList<ClasseMen> list = (ArrayList<ClasseMen>) usuario.ReceberMen();
            listaMensagens.clear();
            listaMensagens.addAll(list);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao listar mensagens", "erro", JOptionPane.ERROR);
        }
    }
    
    private void enableComponents(boolean op) {
        this.jTextNome.setEnabled(!op);
        this.jTextEnvio.setEnabled(op);
        this.BTNCvsGeral.setEnabled(op);
        this.EnviarBTN.setEnabled(op);
        this.ListaCliente.setEnabled(op);
        this.jListMsg.setEnabled(op);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextNome = new javax.swing.JTextField();
        ListaCliente = new javax.swing.JList<>();
        jListMsg = new javax.swing.JList<>();
        jTextEnvio = new javax.swing.JTextField();
        EnviarBTN = new javax.swing.JButton();
        LigarBTN = new javax.swing.JButton();
        SairBTN = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        BTNCvsGeral = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        ListaCliente.setBackground(new java.awt.Color(102, 102, 102));

        jListMsg.setBackground(new java.awt.Color(102, 102, 102));

        EnviarBTN.setBackground(new java.awt.Color(0, 204, 0));
        EnviarBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EnviarBTN.setForeground(new java.awt.Color(255, 255, 255));
        EnviarBTN.setText("ENVIAR MENSAGEM");
        EnviarBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnviarBTNActionPerformed(evt);
            }
        });

        LigarBTN.setBackground(new java.awt.Color(0, 204, 0));
        LigarBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        LigarBTN.setForeground(new java.awt.Color(255, 255, 255));
        LigarBTN.setText("LIGAR");
        LigarBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LigarBTNActionPerformed(evt);
            }
        });

        SairBTN.setBackground(new java.awt.Color(255, 0, 0));
        SairBTN.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SairBTN.setForeground(new java.awt.Color(255, 255, 255));
        SairBTN.setText("SAIR");
        SairBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairBTNActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("NOME:");

        BTNCvsGeral.setBackground(new java.awt.Color(0, 204, 0));
        BTNCvsGeral.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BTNCvsGeral.setForeground(new java.awt.Color(255, 255, 255));
        BTNCvsGeral.setText("LISTAR");
        BTNCvsGeral.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNCvsGeralActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextNome)
                    .addComponent(jLabel1)
                    .addComponent(LigarBTN, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                    .addComponent(SairBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(EnviarBTN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextEnvio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jListMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ListaCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BTNCvsGeral, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextEnvio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextNome, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(LigarBTN)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(SairBTN))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ListaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jListMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EnviarBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BTNCvsGeral, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LigarBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LigarBTNActionPerformed
        try {
            // TODO add your handling code here
            String nome = this.jTextNome.getText();
            this.usuario = new ClasseCliente("localhost", 15500, nome);
            
            String Op = "ENTRAR;" + nome;

            ClasseMen msg = new ClasseMen(Op, "");
            

            semaphore.acquire();
            this.usuario.EviMen(msg);
            semaphore.release();

            String resposta = (String) this.usuario.ReceberMen();
            if (resposta.equalsIgnoreCase("ok")) {
                this.atualizarClientes(usuario);
                this.LigarBTN.setEnabled(false);
                this.SairBTN.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Esse usuário já está online");
                this.LigarBTN.setEnabled(true);
                this.SairBTN.setEnabled(false);
            }

            this.on = true;

        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(this, "Falha ao conectar no servidor!", "Erro", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
            this.LigarBTN.setEnabled(true);
            this.SairBTN.setEnabled(false);
        }
    }//GEN-LAST:event_LigarBTNActionPerformed

    private void EnviarBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnviarBTNActionPerformed
        if (this.BTNCvsGeral.isSelected() || this.ListaCliente.getSelectedIndex() != -1) {
            try {
                String txt = this.jTextEnvio.getText();
                ClasseMen msg = new ClasseMen("ENVIAR;", txt);
                msg.setDestinatarioID(BTNCvsGeral.isSelected() ? 0 : this.ListaCliente.getSelectedValue().getId());
                semaphore.acquire();
                this.usuario.EviMen(msg);
                semaphore.release();
                this.jTextEnvio.setText("");

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Falha ao enviar mensagem!", "Erro", JOptionPane.ERROR_MESSAGE);

            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione a conversa na qual deseja enviar mensagem", "Falha", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_EnviarBTNActionPerformed

    private void SairBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairBTNActionPerformed
        try {
                this.LigarBTN.setEnabled(true);
                this.SairBTN.setEnabled(false);
            this.usuario.finalizar();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Falha ao desconectar do servidor!", "Erro", JOptionPane.ERROR_MESSAGE);

        }

        this.on = false;
    }//GEN-LAST:event_SairBTNActionPerformed

    private void BTNCvsGeralActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNCvsGeralActionPerformed
        this.ListaCliente.setSelectedIndex(-1);
        if (this.BTNCvsGeral.isSelected()) {
            try {
                ClasseMen msg = new ClasseMen("LISTAR;MENSAGENS;GERAL", "");
                while (flag) {

                }
                semaphore.acquire();
                this.usuario.EviMen(msg);
                semaphore.release();
                this.esperaMsg();
                flag = false;
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }
    }//GEN-LAST:event_BTNCvsGeralActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new FramePrincipal().setVisible(true);
                } catch (InterruptedException ex) {
                    Logger.getLogger(FramePrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNCvsGeral;
    private javax.swing.JButton EnviarBTN;
    private javax.swing.JButton LigarBTN;
    private javax.swing.JList<ClasseCliente> ListaCliente;
    private javax.swing.JButton SairBTN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<ClasseMen> jListMsg;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextEnvio;
    private javax.swing.JTextField jTextNome;
    // End of variables declaration//GEN-END:variables
}
