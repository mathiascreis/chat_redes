package DAO;

import Classes.ClasseCliente;
import Conexao.ConexaoDoPG;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;



public class Clientao {

    private Connection conexaoBD;

    public Clientao() {
        this.conexaoBD = ConexaoDoPG.getConexaoPostgres();
    }

    public boolean insert(ClasseCliente novCli) {
        String sql = "INSERT INTO victor.clientebd(nome, online) VALUES (?,?) returning id";

        try (PreparedStatement trans = this.conexaoBD.prepareStatement(sql)) {
            trans.setString(1, novCli.getNome());
            trans.setBoolean(2, novCli.isOnline());

            ResultSet resultado = trans.executeQuery();
            if(resultado.next()) {
                novCli.setId(resultado.getInt("id"));
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Erro inserção");
        }
        return true;
    }
    public ArrayList<ClasseCliente> selectALL() throws SQLException{
        ArrayList<ClasseCliente> retorno = new ArrayList<>();
        
        String sql = "SELECT nome, id, online FROM victor.clientebd ORDER BY online DESC";
        try(PreparedStatement trans = this.conexaoBD.prepareStatement(sql)){
            ResultSet resultado = trans.executeQuery();
            
            while(resultado.next()){
                ClasseCliente cliente = new ClasseCliente();
                cliente.setOnline(resultado.getBoolean("online"));
                cliente.setId(resultado.getInt("id"));
                cliente.setNome(resultado.getString("nome"));
            
                retorno.add(cliente);
                
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return retorno;
    }
    
    public ClasseCliente selecionaNome(String Nome) throws SQLException{
        ClasseCliente retorno; 
        
        String sql = "SELECT nome, id, online FROM victor.clientebd WHERE nome = ?";
        try(PreparedStatement trans = this.conexaoBD.prepareStatement(sql)){
            trans.setString(1, Nome);
            
            ResultSet resultado = trans.executeQuery();
            
            if(resultado.next()){
                retorno = new ClasseCliente();
                retorno.setOnline(resultado.getBoolean("online"));
                retorno.setId(resultado.getInt("id"));
                retorno.setNome(Nome);
                
                return retorno;
            }else {
                return null;
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            return null;
        }
    
    }
    
    public ClasseCliente SelecionaId (int id) throws SQLException{
        ClasseCliente retorno;
        
        String sql = "SELECT nome, id, online FROM victor.ClienteBD WHERE id = ?";
        try(PreparedStatement trans = this.conexaoBD.prepareStatement(sql)){
            trans.setInt(1, id);
            
            ResultSet resu = trans.executeQuery();
            if(resu.next()){
                retorno = new ClasseCliente();
                retorno.setOnline(resu.getBoolean("online"));
                retorno.setId(id);
                retorno.setNome(resu.getString("nome"));
                
                return retorno;
            }else {
                return null;
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            return null;
        }
    }
    
    public boolean setOnline(boolean on, long id){
        String sql = "UPDATE victor.ClienteBD SET online = ? WHERE id = ?";
        
        try(PreparedStatement trans = this.conexaoBD.prepareStatement(sql)) {
            trans.setBoolean(1, on);
            trans.setLong(2, id);
            
            trans.execute();
            return true;
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            return false;
        }
    }
}
