package DAO;

import Classes.ClasseMen;
import Conexao.ConexaoDoPG;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mensajao {
    private Connection conecta;
    
    public Mensajao(){
        this.conecta = ConexaoDoPG.getConexaoPostgres();
    }
    
    public boolean insert(ClasseMen mensagem){
        String sql = "INSERT INTO victor.MensagemBD(texto, remetente, conversa) VALUES (?,?,?) returning id";
        
        try(PreparedStatement trans = conecta.prepareStatement(sql)){
            trans.setString(1, mensagem.getTexto());
            trans.setInt(2, (int) mensagem.getRemetenteID());
            trans.setInt(3, (int) mensagem.getConversaID());

            ResultSet result = trans.executeQuery();
        } catch (SQLException ex){
            System.out.println(ex.getMessage());
            Logger.getLogger(Mensajao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println(ex.getMessage());
        }
        return false;
    }
    
    public ArrayList<ClasseMen> select(int conID){
        ArrayList<ClasseMen> retorno = new ArrayList<>();
        
        String sql = "SELECT M.id, M.texto, C.nome FROM victor.MensagemBD M JOIN victor.ClienteBD C ON C.id = M.remetente WHERE conversa = ? ORDER BY id";
        try(PreparedStatement trans = conecta.prepareStatement(sql)){
            trans.setInt(1, conID);

            ResultSet resultado = trans.executeQuery();
            
            while (resultado.next()) {
                ClasseMen msg = new ClasseMen(resultado.getString("nome"),
                        resultado.getInt("id"),
                        resultado.getString("texto"));
                retorno.add(msg);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            Logger.getLogger(Mensajao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
    
    public ArrayList<ClasseMen> select() {
        ArrayList<ClasseMen> retorno = new ArrayList<>();
        String sql = "SELECT M.id, M.texto, C.nome FROM victor.MensagemBD M JOIN victor.ClienteBD C ON C.id = M.remetente WHERE conversa = 0 ORDER BY id";
        try (PreparedStatement trans = conecta.prepareStatement(sql)) {
            ResultSet resultado = trans.executeQuery();

            while (resultado.next()) {
                ClasseMen msg = new ClasseMen(resultado.getString("nome"),
                        resultado.getInt("id"),
                        resultado.getString("texto"));
                retorno.add(msg);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            Logger.getLogger(Mensajao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
}
