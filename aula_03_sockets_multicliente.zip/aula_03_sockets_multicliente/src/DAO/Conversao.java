package DAO;


import Conexao.ConexaoDoPG;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Conversao {
    private Connection conexao;
    
    public Conversao(){
        this.conexao = ConexaoDoPG.getConexaoPostgres();
    }
    
    public int insert(int reme, int desti) throws SQLException{
        System.out.println(reme + " " + desti);
        String sql = "INSERT INTO victor.conversabd(cliente1,cliente2) VALUES (?,?) returning id";
        
        try(PreparedStatement trans = conexao.prepareStatement(sql)){
            trans.setInt(1, reme);
            trans.setInt(2, desti);
            
            ResultSet result = trans.executeQuery();
            
            if(result.next()) {
                System.out.println("funfou!!!");
                return result.getInt("id");
            }else {
                System.err.println("Nao foi retornado nada");
                return 0;
            }
            
        } catch (SQLException ex) {
            
            System.out.println(ex.getMessage());
            return 0;
        }
    }
    public int select(int remetente, int destinatario) throws SQLException{
        String sql = "SELECT id FROM victor.conversabd WHERE cliente1 = ? AND cliente2 = ? OR cliente1 = ? AND cliente2 = ?";
        System.out.println("ddddddddddd" + destinatario);
        try(PreparedStatement trans = conexao.prepareStatement(sql)){
            trans.setInt(1, remetente);
            trans.setInt(4, remetente);
            trans.setInt(2, destinatario);
            trans.setInt(3, destinatario);
            
            ResultSet resultado = trans.executeQuery();
            if(resultado.next()) {
                return resultado.getInt("id");
            } else {
                return insert(remetente, destinatario);
            }
        } catch (SQLException ex) {
            System.out.println("d");
            ex.printStackTrace();
            System.out.println(ex.getMessage());
            Logger.getLogger(Conversao.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    
    }
    
    
    
}
