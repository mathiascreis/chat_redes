package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexaoDoPG {

    private static Connection conexaoPG;

    public static Connection getConexaoPostgres() {

        //nao existe conexao ainda
        if (conexaoPG == null) {
            try {
                conexaoPG = DriverManager.getConnection("jdbc:postgresql://10.90.24.56:5432/aula","aula","aula");

//                String url = "jdbc:postgresql://200.18.128.56:5432/Vitao&Mathias";
//                String usuario = "aula";
//                String senha = "aula";
//
//                Connection con = DriverManager.getConnection(url, usuario, senha);
                System.out.println("Conectouuu");
//                return con;
                
            } catch (SQLException ex) {
                Logger.getLogger(ConexaoDoPG.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Erro na Conexao");
                return null;
            }
        }
        return conexaoPG;
    }
}