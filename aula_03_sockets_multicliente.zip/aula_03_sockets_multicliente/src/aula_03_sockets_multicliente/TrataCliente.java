package aula_03_sockets_multicliente;

import Classes.ClasseCliente;
import Classes.ClasseMen;
import DAO.Clientao;
import DAO.Conversao;
import DAO.Mensajao;
import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.SocketException;

public class TrataCliente implements Runnable {

    private Socket soquete_cliente;
    private ObjectOutputStream saida;
    private ObjectInputStream entrada;
    private Clientao clienteDAO;
    private Mensajao msgDAO;
    private Conversao cnvDAO;
    private int id;
//    private ArrayList<Mensagem> mensagens;
//    private ArrayList<String> clientes;

    public TrataCliente(Socket soquete_cliente) throws Exception {
        super();
        this.id = 0;
        this.soquete_cliente = soquete_cliente;
        this.clienteDAO = new Clientao();
        this.msgDAO = new Mensajao();
        this.cnvDAO = new Conversao();
        this.saida = new ObjectOutputStream(this.soquete_cliente.getOutputStream());
        this.entrada = new ObjectInputStream(this.soquete_cliente.getInputStream());
    }

    public void enviar_mensagem(Object mensagem) throws Exception {
        this.saida.writeObject(mensagem);
        System.out.println(mensagem);
    }

    public Object receber_mensagem() throws Exception {
        Object obj = this.entrada.readObject();
        System.out.println(obj);
        return obj;
    }

    public void finalizar() throws IOException {
        this.soquete_cliente.close();
//        this.clientes.remove(this);
    }

//    @Override
//    public void run() {
//        try {
//            Mensagem mensagem = null;
//               enviar_mensagem("Conexão estabelecida. Digite '1' para entrar no sistema.");
//            while (true) {
//                
//                mensagem = (Mensagem) receber_mensagem();
//
//                if (mensagem.getTexto().equalsIgnoreCase("1")) {
//                    
//                    System.out.println("Você entrou no sistema!!");
//                    // Verifica se o nome já está na lista de clientes
//                    
//                    String clienteIP = String.valueOf(Cliente.nome);
//                    
//                    if (!clientes.contains(clienteIP)) {
//                        clientes.add(clienteIP);
//                    }
//                
//                }
//                if (mensagem.getTexto().equalsIgnoreCase("4")) {
//                    enviar_mensagem("Clientes conectados:" + clientes);
//                 
//                }
//                if (mensagem.getTexto().equalsIgnoreCase("3")) {
//                    enviar_mensagem("Mensagens que foram enviadas: " + mensagens);
//               
//                }
//                if (mensagem.getTexto().equalsIgnoreCase("2")) {
//                    enviar_mensagem("Você desconectou.");
//                    finalizar();
//                    break;
//                }
//                if (mensagem.getTexto().equalsIgnoreCase("5")) {
//                    enviar_mensagem("Digite a mensagem a ser enviada:");
//                    mensagem = (Mensagem) receber_mensagem();
//                    
//                    
//                    mensagens.add(mensagem);
//                    enviar_mensagem("Mensagem enviada com sucesso.");
//                    System.out.println(mensagem);
//                }
//                
//                Clientao VamosEnviar = new Clientao();
//                VamosEnviar.cadastraMensagem(mensagem);
//                
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
    @Override
    public void run() {
        try {
            ClasseMen mensagem;
            String comand[];

            OUTER:
            do {
                mensagem = (ClasseMen) receber_mensagem();
                System.out.println(" aaaaaa " + mensagem.getOperacao());

                comand = mensagem.getOperacao().split(";");
                System.out.println(comand[0]);
                switch (comand[0]) {
                    case "ENCERRAR" -> {
                        clienteDAO.setOnline(false, id);
                        break OUTER;
                    }

                    case "ENVIAR" -> {
                        int idConversa;
                        System.out.println(id + " " + mensagem.getDestinatarioID());
                        if ((int) mensagem.getDestinatarioID() != 0) {
                            idConversa = cnvDAO.select(this.id, (int) mensagem.getDestinatarioID());
                        } else {
                            idConversa = 0;
                        }
                        System.out.println("bbb" + idConversa);
                        mensagem.setConversaID(idConversa);
                        mensagem.setRemetenteID(this.id);
                        if (msgDAO.insert(mensagem)) {
                            //enviar_mensagem("OK");
                        } else {
                            //   enviar_mensagem("ERRO");
                        }
                    }

                    case "ENTRAR" -> {
                        ClasseCliente cliente = clienteDAO.selecionaNome(comand[1]);
                        if (cliente == null) {
                            cliente = new ClasseCliente(id, null);
                            cliente.setNome(comand[1]);
                            cliente.setOnline(true);
                            if (clienteDAO.insert(cliente)) {
                                this.id = (int) cliente.getId();
                                enviar_mensagem("OK");
                                enviar_mensagem(clienteDAO.selectALL());
                            } else {
                                enviar_mensagem("ERRO");
                            }
                        } else {
                            if (cliente.isOnline()) {
                                enviar_mensagem("ERRO");
                            } else {
                                enviar_mensagem("OK");
                                enviar_mensagem(clienteDAO.selectALL());
                                cliente.setOnline(true);
                                clienteDAO.setOnline(true, cliente.getId());
                                this.id = (int) cliente.getId();
                            }
                        }
                    }

                    case "LISTAR" -> {
                        switch (comand[1]) {
                            case "CLIENTES" ->
                                enviar_mensagem(clienteDAO.selectALL());
                            case "MENSAGENS" -> {
                                if (comand[2].equals("GERAL")) {
                                    enviar_mensagem(msgDAO.select());
                                } else if (comand[2].equals("DIRETA")) {
                                    System.out.println(id + " " + mensagem.getDestinatarioID());
                                    int id_conversa = cnvDAO.select(this.id, (int) mensagem.getDestinatarioID());
                                    enviar_mensagem(msgDAO.select(id_conversa));
                                }
                            }
                            default ->
                                enviar_mensagem(null);
                        }
                    }

                    default -> {
                        System.err.println(mensagem.getOperacao());
                        System.err.println(comand[0]);
                        throw new AssertionError();

                    }
                }

            } while (!mensagem.getTexto().equals("ENCERRAR"));
            System.out.println("\u001b[32m" + soquete_cliente + " - Desconectou!");
            finalizar();
        } catch (SocketException ex) {
            if (this.id != 0) {
                System.err.println("CLIENTE DESCONECTOU");
                clienteDAO.setOnline(false, id);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        clienteDAO.setOnline(false, id);
    }
}
