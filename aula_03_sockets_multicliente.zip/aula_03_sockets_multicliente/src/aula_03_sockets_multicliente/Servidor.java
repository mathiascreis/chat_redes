package aula_03_sockets_multicliente;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

public class Servidor {

    private ServerSocket soquete_servidor;
    //private ArrayList<Mensagem> mensagens;
    //private ArrayList<String> clientes;

    public Servidor(int porta) throws Exception {
        super();
        this.soquete_servidor = new ServerSocket(porta);
//        this.mensagens = new ArrayList<Mensagem>();
//        this.clientes = new ArrayList<String>();
    }

    public void finalizar() throws IOException {
        this.soquete_servidor.close();
    }

    public static void main(String[] args) throws Exception {
        Servidor servidor = new Servidor(15500);
        Socket soqueteCliente = null;

        while (true) {
            try {
                soqueteCliente = servidor.soquete_servidor.accept();
                System.out.println("\u001b[32m" + soqueteCliente + " - Conectou!");
                new Thread(new TrataCliente(soqueteCliente)).start();

//            Socket soqueteCliente = servidor.soquete_servidor.accept();
//            TrataCliente cliente = new TrataCliente(soqueteCliente, servidor.mensagens, servidor.clientes);
//            new Thread(cliente).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
