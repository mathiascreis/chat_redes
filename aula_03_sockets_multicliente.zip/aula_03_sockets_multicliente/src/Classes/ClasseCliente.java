package Classes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;

public class ClasseCliente implements Serializable {

    private Socket soquete;
    private ObjectOutputStream saida;
    private ObjectInputStream estrada;
    private ArrayList<ClasseMen> mensagens;
    private long id;
    private String nome;
    private boolean online;

    public ClasseCliente(String endereco, int porta, String nome) throws Exception {
        this.soquete = new Socket(endereco, porta);
        this.saida = new ObjectOutputStream(this.soquete.getOutputStream());
        this.estrada = new ObjectInputStream(this.soquete.getInputStream());
        this.nome = nome;
    }

    public ClasseCliente(long id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public ClasseCliente() {

    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void EviMen(Object men) throws Exception {
        System.out.println("[Enviado] : " + men);
        this.saida.writeObject(men);
    }

    public Object ReceberMen() throws Exception {
        Object OO = this.estrada.readObject();
        System.out.println("Recebido : " + OO);
        return OO;
    }

    public void finalizar() throws IOException {
        this.soquete.close();
    }

    @Override
    public String toString() {
        String dis = this.online ? "ON" : "OFF";
        return this.nome + "[" + dis + "]";
    }
}
