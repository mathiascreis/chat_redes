package Classes;

import java.io.Serializable;

public class ClasseMen implements Serializable{
    
    private String nome;
    private long id;
    private long destinatarioID;
    private long remetenteID;
    private long conversaID;
    private String texto;
    private String operacao;

    public ClasseMen(String operacao, String texto) {
        super();
        this.texto = texto;
        this.operacao = operacao;
    }
    
    

    public ClasseMen(String nome, long id, String texto) {
        this.nome = nome;
        this.id = id;
        this.texto = texto;
    }

    public ClasseMen(long id, long destinatarioID, long remetenteID, String texto) {
        this.id = id;
        this.destinatarioID = destinatarioID;
        this.remetenteID = remetenteID;
        this.texto = texto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDestinatarioID() {
        return destinatarioID;
    }

    public void setDestinatarioID(long destinatarioID) {
        this.destinatarioID = destinatarioID;
    }

    public long getRemetenteID() {
        return remetenteID;
    }

    public void setRemetenteID(long remetenteID) {
        this.remetenteID = remetenteID;
    }

    public long getConversaID() {
        return conversaID;
    }

    public void setConversaID(long conversaID) {
        this.conversaID = conversaID;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }
    
    @Override
    public String toString(){
        return "(" + nome + ") = " + texto + ";";
    }

    
    
}
